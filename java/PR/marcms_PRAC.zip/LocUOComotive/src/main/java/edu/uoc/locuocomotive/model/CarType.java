package edu.uoc.locuocomotive.model;

public enum CarType {
    FIRST_CLASS,
    SECOND_CLASS,
    THIRD_CLASS
}
