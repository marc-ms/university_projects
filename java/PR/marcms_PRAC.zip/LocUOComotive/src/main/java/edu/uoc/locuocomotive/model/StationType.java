package edu.uoc.locuocomotive.model;

public enum StationType {
    UNDERGROUND,
    OVERGROUND,
    ELEVATED
}
